package io.github.lucienh.common.dao

import org.springframework.data.elasticsearch.core.ElasticsearchOperations

/**
 * Created by h on 15-10-29.
 */
trait ElasticSearchTemplateExt extends ElasticsearchOperations {

}
